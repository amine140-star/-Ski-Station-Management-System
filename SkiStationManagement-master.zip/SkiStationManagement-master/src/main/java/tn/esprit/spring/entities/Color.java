package tn.esprit.spring.entities;

public enum Color {
	GREEN, BLUE, RED, BLACK
}
