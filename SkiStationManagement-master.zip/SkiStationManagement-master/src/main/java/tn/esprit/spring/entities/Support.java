package tn.esprit.spring.entities;

public enum Support {
	SKI, SNOWBOARD
}
